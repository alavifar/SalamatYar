# SalamatYar — free break reminder for Windows, macOS and Linux

[![License: MIT](https://img.shields.io/badge/license-MIT-0d9488)](LICENSE)
![Platform: Windows, macOS, Linux](https://img.shields.io/badge/platform-Windows%20%7C%20macOS%20%7C%20Linux-2563eb)
![Languages: 6](https://img.shields.io/badge/languages-fa%20%7C%20en%20%7C%20ar%20%7C%20ru%20%7C%20zh%20%7C%20sv-7c3aed)
![No installation](https://img.shields.io/badge/install-not%20needed-d97706)
[![Downloads](https://img.shields.io/github/downloads/alavifar/SalamatYar/total?color=0d9488)](https://github.com/alavifar/SalamatYar/releases)

A free, open-source health reminder for people who spend hours at a computer: eye breaks with the 20-20-20 rule, movement and stretch breaks, and water reminders. It runs on Windows, macOS and Linux, and no data leaves your computer.

**Languages:** فارسی · English · العربية · Русский · 中文 · Svenska — [راهنمای فارسی](README.fa.md)

## Download

| System | Edition | Download |
| --- | --- | --- |
| Windows 10 and 11 | 1.3, stable, nothing to install | **[SalamatYar.zip](https://github.com/alavifar/SalamatYar/releases/latest/download/SalamatYar.zip)** |
| macOS (Intel and Apple silicon) | 2.0 preview | [SalamatYar_2.0.0_universal.dmg](https://github.com/alavifar/SalamatYar/releases/download/app-v2.0.0/SalamatYar_2.0.0_universal.dmg) |
| Linux (Debian, Ubuntu) | 2.0 preview | [SalamatYar_2.0.0_amd64.deb](https://github.com/alavifar/SalamatYar/releases/download/app-v2.0.0/SalamatYar_2.0.0_amd64.deb) |
| Linux (other distributions) | 2.0 preview | [SalamatYar_2.0.0_amd64.AppImage](https://github.com/alavifar/SalamatYar/releases/download/app-v2.0.0/SalamatYar_2.0.0_amd64.AppImage) |
| Windows, installer | 2.0 preview | [SalamatYar_2.0.0_x64-setup.exe](https://github.com/alavifar/SalamatYar/releases/download/app-v2.0.0/SalamatYar_2.0.0_x64-setup.exe) |

The 2.0 preview is the cross-platform edition, built with Tauri. It has the same features as 1.3, but the macOS and Linux builds have not yet been tested on real machines; [reports are welcome](https://github.com/alavifar/SalamatYar/issues). The apps are not code-signed: on macOS, choose **Open Anyway** in Privacy & Security the first time.

![Dashboard](docs/dashboard-en.png)

If SalamatYar helps you, a ⭐ on this repository helps other people find it.

## What it does

- **Eye break:** every 20 minutes, look about 6 metres (20 feet) away for 20 seconds (the 20-20-20 rule).
- **Move and stretch:** every 30 minutes, stand up and move for 2 minutes.
- **Water:** a small reminder every 60 minutes.
- **58 suggested activities:** 14 for the eyes, 22 stretches and movements, 8 water habits and 14 ergonomics tips. Each reminder shows one or two, and none repeats until the whole set has been shown.
- **Three reminder styles:** full screen, a small window in the corner, or only a notification next to the Windows clock.
- A chime for every message and music during breaks. You can pick your own audio files.
- Daily statistics, absence detection (time away from the computer counts as a break) and an ergonomics guide with sources.
- Dark, light and automatic themes. Every timing can be changed, and each setting shows a preview the moment you change it.

| Full screen | Small window | Languages |
| --- | --- | --- |
| ![Eye break](docs/eye-break-en.png) | ![Small window](docs/reminder-window-en.png) | ![Languages](docs/languages.png) |

| Settings | Persian (right-to-left) |
| --- | --- |
| ![Settings](docs/settings-en.png) | ![Persian](docs/dashboard-fa.png) |

## Run it on Windows (edition 1.3)

1. [Download SalamatYar.zip](https://github.com/alavifar/SalamatYar/releases/latest/download/SalamatYar.zip) and extract the whole folder.
2. Double-click `SalamatYar.exe`.
3. On first run the app generates its sound files in the same folder.

The program is not code-signed, so Windows may show "Windows protected your PC" the first time. Choose **More info**, then **Run anyway**. `SalamatYar.exe` is only a small launcher for `SalamatYar.ps1`; its source is in [launcher/Launcher.cs](launcher/Launcher.cs). If you prefer not to run the launcher, double-click `Run.cmd` instead.

Closing the window does not exit the app; it stays next to the Windows clock. Right-click its icon to exit.

## Where the default timings come from

| Reminder | Default | Based on |
| --- | --- | --- |
| Eye break | every 20 min, 20 sec | 20-20-20 rule: American Optometric Association, American Academy of Ophthalmology |
| Movement | every 30 min, 2 min | UK HSE (short, frequent breaks), Cornell 20-8-2 pattern, WHO 2020 guidelines |
| Water | every 60 min | A convenience default; there is no single standard |

There is no single worldwide standard for movement breaks; the defaults combine several published recommendations. SalamatYar is a reminder tool and does not replace medical advice.

## Privacy

The app never connects to the internet. Settings and statistics are stored only in the app folder.

## Frequently asked questions

**Is it really free?** Yes. It is released under the MIT license, with no ads, accounts or tracking.

**Does it work on macOS and Linux?** Yes, with the 2.0 preview from the download table above. It is new on those systems, so please report anything that does not work.

**Why does Windows warn me?** The launcher is not code-signed. The whole source is in this repository, and you can start the app with `Run.cmd` instead of the launcher.

**Can I change the timings?** Yes, everything is in Settings, with a button to return to the recommended values.

**Can it start with Windows?** Yes, there is a checkbox in Settings.

**My language is missing or a translation is wrong.** All texts are in `lang.json`. See [CONTRIBUTING.md](CONTRIBUTING.md); corrections from native speakers are very welcome.

## How it is built

There are two editions with the same features and the same texts (`lang.json`). The cross-platform edition in [app/](app/) is written in Rust with an HTML interface (Tauri 2); see [app/README.md](app/README.md). The Windows edition is described below.

A single PowerShell script (`SalamatYar.ps1`) with a WPF interface, so it runs on a stock Windows installation with nothing to install. Sounds and music are synthesized by the app itself. All interface text lives in `lang.json`. `tools/build.ps1` compiles the launcher and builds the download package with the C# compiler that ships with Windows.

See [CONTRIBUTING.md](CONTRIBUTING.md) to add a language, fix a translation or change the code, and [CHANGELOG.md](CHANGELOG.md) for the release history.
## License

[MIT](LICENSE). You may use, change and share it freely; keep the copyright notice.

## Author

Seyed Hamidreza Alavifar — Telegram: [@ShrAlavifar](https://t.me/ShrAlavifar)
